const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.post('/translate', async (req, res) => {
  const { q, source, target } = req.body;
  const apiKey = process.env.GOOGLE_API_KEY;
  const url = `https://translation.googleapis.com/language/translate/v2?key=${apiKey}`;

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ q, target, source })
    });
    const data = await response.json();
    res.json({ translatedText: data.data.translations[0].translatedText });
  } catch (err) {
    res.status(500).json({ error: 'Translation failed' });
  }
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));